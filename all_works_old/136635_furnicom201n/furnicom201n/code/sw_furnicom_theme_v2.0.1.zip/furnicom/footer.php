<?php furnicom_footer_check(); ?>
	<?php if(furnicom_options()->getCpanelValue('back_active') == '1') { ?>
		<div class="btt">
			<div id="furnicom-totop">
				<a class="furnicom-totop" href="#" ></a>
			</div>
		</div>
	<?php }?>
	</div>
</div>
<?php wp_footer(); ?>
</body>
</html>