<?php
	furnicom_blog_listing_check();
?>