<?php
$less_variables = array(
	'color'        => '#f5a52f',
	'a-color'      => '#f6a873',
	'body-color'   => '#444',
	'border-color' => '#cecece',
	'url'     => "'../assets/img/orange2'",
);

