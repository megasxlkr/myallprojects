<?php
$less_variables = array(
	'color'        => '#beae59',
	'a-color'      => '#beae59',
	'body-color'   => '#444',
	'border-color' => '#cecece',
	'url'     => "'../assets/img/default'",
);

