<?php
$less_variables = array(
	'color'        => '#254470',
	'a-color'      => 'desaturate(darken(@color, 20%),4%)',
	'body-color'   => '#444',
	'border-color' => '#cecece',
	'url'     => "'../assets/img/darkblue'",
);


