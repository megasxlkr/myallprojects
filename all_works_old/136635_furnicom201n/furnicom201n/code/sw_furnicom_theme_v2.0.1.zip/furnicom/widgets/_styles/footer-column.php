<?php
/**
 * Widget Style: Widget First Footer
 *
 */

$ws['footer-column'] = array(
	'before_title' => '<h2>',
	'after_title' => '</h2>',
	'before_widget' => '<div id="%1$s"  id="%1$s" class="col-lg-3 col-md-3  col-sm-6 footer-column"><div class="footer-border">',
	'after_widget' => '</div></div>',
);