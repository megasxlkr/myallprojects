<?php
/**
 * Widget Style: Col-lg-6
 *
 */
$ws['col-6'] = array(
		'before_title' => '<h3><span>',
		'after_title' => '</span></h3>',
		'before_widget' => '<div id="%1$s" id="%1$s" class="col-lg-6 col-md-6 col-sm-6 widget %2$s "><div class="widget-inner">',
		'after_widget' => '</div></div>',
	);