<?php
/**
 * Widget Style: title1
 *
 */

$ws['title1'] = array(
	'before_widget' => '<div id="%1$s" class="widget %1$s %2$s"><div class="widget-inner">',
	'after_widget' => '</div></div>',
	'before_title' => '<div id="%1$s" class="block-title-widget"><h2><span>',
	'after_title' => '</span></h2></div>'
);