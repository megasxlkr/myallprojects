<?php
/**
 * Widget Style: Default
 *
 */

$ws['xhtml'] = array(
	'before_widget' => '<div id="%1$s" id="%1$s" class="widget %1$s %2$s">',
	'after_widget' => '</div>',
	'before_title' => '<h3 class="widget-title">',
	'after_title' => '</h3>'
);