<?php

$ws['col-3-footer'] = array(
		'before_title' => '<div class="button-ver-menu">',
		'after_title' => '</div>',
		'before_widget' => '<div id="%1$s" id="%1$s" class="col-lg-3 col-md-3 col-sm-12 widget %1$s %2$s"><div class="widget-inner">',
		'after_widget' => '</div></div>',
	);