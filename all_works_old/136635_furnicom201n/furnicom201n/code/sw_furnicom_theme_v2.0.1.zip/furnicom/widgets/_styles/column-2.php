<?php

$ws['column-2'] = array(
		'before_title' => '<h3>',
		'after_title' => '</h3>',
		'before_widget' => '<div id="%1$s"  id="%1$s" class="column-2 col-lg-2 col-md-2 col-sm-6 col-xs-6 widget %1$s %2$s" data-scroll-reveal="enter right move 20px wait 0.3s"><div class="widget-inner">',
		'after_widget' => '</div></div>',
	);