<?php 

$widget_id = isset( $widget_id ) ? $widget_id : 'category_slide_'.rand().time();
?>
<div id="<?php echo $widget_id; ?>" class="category-brand-tab">
	<div class="category-tab-content clearfix">
		<?php
			if( $category == '' ){
				return esc_html__( 'Please select a category', 'sw_woocommerce' ) . '</div>';
			}
			if( !is_array( $category ) ){
				$category = explode( ',', $category );
			}
		?>
		<ul class="nav nav-tabs tab-left pull-left" role="tablist">
		<?php 
			if( $title1 != '' ){
					$titles = strpos($title1, ' ');
		?>
			<li class="block-title">
				<?php 
					if( $titles ) : 
						echo '<h3><span>' . substr( $title1, 0, $titles ) . ' </span>' . substr( $title1, $titles + 1 ) .'</h3>'; 
					else: 
						echo '<h3><span>' . substr( $title1, 0, 1 ) . '</span>' . substr( $title1, 1 ) .'</h3>'; 
					endif;
				?>
			</li>
		<?php } ?>
		<!-- Tab Content -->
		<?php
			$count = floor( count( $category )/2 );
			for( $i = 0; $i < $count; $i++ ){
				$term = get_term_by('slug', $category[$i], 'product_cat');		
				if( $term ) :
				$thumbnail_id 	= absint( get_term_meta( $term->term_id, 'thumbnail_id', true ) );
				$thumb = wp_get_attachment_image( $thumbnail_id, array(350, 230) );
		?>
				<li class="<?php echo ( $i == 0 ) ? 'active' : '' ?>">
					<a href="#<?php echo 'category_tab_'. esc_attr( $term->term_id ); ?>" data-toggle="tab" title="<?php echo esc_attr( $term->name ); ?>">
						<div class="item-image"><?php echo $thumb; ?></div>
					</a>
				</li>
				<?php endif; ?>
			<?php } ?>
		</ul>
		<div class="tab-content">
		<?php
		foreach( $category as $key => $cat ){
			$term = get_term_by('slug', $cat, 'product_cat');	
			if( $term ) :
			$thumbnail_id 	= absint( get_term_meta( $term->term_id, 'thumbnail_id1', true ));
			$thumb = wp_get_attachment_image( $thumbnail_id, 'full', 0, array( 'class' => 'category-image' ) );
		?>
			<div id="<?php echo 'category_tab_'. esc_attr( $term->term_id ); ?>" class="tab-pane fade in <?php echo ( $key == 0 ) ? 'active' : '' ?>">
				<div class="tab-pane-inner">
					<?php echo $thumb; ?>
					<div class="item-description">
						<?php echo term_description( $term->term_id, 'product_cat' ); ?>
						<a href="<?php echo get_term_link( $term->term_id ); ?>" title="<?php echo esc_attr( $term->name ) ?>"><?php echo esc_html__( 'Shop Now', 'sw_woocommerce' ); ?></a>
					</div>
				</div>
			</div>
			<?php endif; ?>
		<?php } ?>
		</div>
		<ul class="nav nav-tabs tab-right pull-left" role="tablist">
		<?php
			for( $j = $count; $j < count( $category ); $j++ ){
				$term = get_term_by('slug', $category[$j], 'product_cat');		
				if( $term ) :
				$thumbnail_id 	= absint( get_term_meta( $term->term_id, 'thumbnail_id', true ) );
				$thumb = wp_get_attachment_image( $thumbnail_id, array(350, 230) );
		?>
				<li class="">
					<a href="#<?php echo 'category_tab_'. esc_attr( $term->term_id ); ?>" data-toggle="tab" title="<?php echo esc_attr( $term->name ); ?>">
						<div class="item-image"><?php echo $thumb; ?></div>
					</a>
				</li>
				<?php endif; ?>
			<?php } ?>
		</ul>
	</div>
</div>	