<?php 
	if( $category == '' ){
		return '<div class="alert alert-warning alert-dismissible" role="alert">
			<a class="close" data-dismiss="alert">&times;</a>
			<p>'. esc_html__( 'Please select a category for SW Woocommerce Category Slider. Layout ', 'sw_woocommerce' ) . $layout .'</p>
		</div>';
	}
	if( !is_array( $category ) ){
		$category = explode( ',', $category );
	}
	$widget_id = isset( $widget_id ) ? $widget_id : 'category_listing_'.rand().time();
?>
<div id="<?php echo $widget_id; ?>" class="multi-category-listing">
	<!-- Title -->
	<?php if (  $title1 != '' ) : ?>
	<div class="box-slider-title">
		<h2><?php echo esc_html( $title1 ); ?></h2>
	</div>
	<?php endif; ?>
	<div class="wrap">
	<!-- content listing -->
	<?php foreach( $category as $cat ) { ?>
	<div class="multi-category-wrapper">
	<?php			
		$term = get_term_by('slug', $cat, 'product_cat');	
		if( $term ) :
			$thumbnail_id 	= get_term_meta( $term->term_id, 'thumbnail_id', true );
			$thumb = wp_get_attachment_image( $thumbnail_id,'full' );
	?>
			<?php if( $thumb ) : ?>
			<div class="mcategory-item item-thumb">
				<?php echo $thumb; ?>
				<div class="thumb-content">
					<h3><a href="<?php echo get_term_link( $term ); ?>"><?php echo $term->name; ?></h3>
					<?php if( $term->description != '' ) : ?>
					<div class="thumb-description"><?php echo $term->description; ?></div>
					<?php endif; ?>
					<a href="<?php echo get_term_link( $term ); ?>" class="thumb-button"><?php echo esc_html__( 'Shop Now', 'sw_woocommerce' ); ?></a>
				</div>
			</div>
			<?php endif; ?>
			
			<?php 
				$default = array(
					'post_type' => 'product',		
					'orderby' => $orderby,
					'post_status' => 'publish',
					'showposts' => $numberposts,
					'tax_query' => array(
						array(
							'taxonomy'  => 'product_cat',
							'field'     => 'slug',
							'terms'     => $cat 
						)
					)
				);
				$list = new WP_Query( $default );
				while( $list->have_posts() ) : $list->the_post(); global $product, $post;
			?>
				<div class="mcategory-item item-product">
					<div class="item-thumb">
						<?php the_post_thumbnail( 'furnicom_multi_category' );?>
						<?php
							$nonce = wp_create_nonce("furnicom_quickviewproduct_nonce");
							$link = admin_url('admin-ajax.php?ajax=true&amp;action=furnicom_quickviewproduct&amp;post_id='.$post->ID.'&amp;nonce='.$nonce);
							$linkcontent ='<a href="'. $link .'" data-fancybox-type="ajax" class="group fancybox fancybox.ajax">'.apply_filters( 'out_of_stock_add_to_cart_text', __( 'Quick View ', 'yatheme' ) ).'</a>';	
							?><?php echo $linkcontent; ?>
						<!-- add to cart, wishlist, compare -->
						<?php do_action( 'woocommerce_after_shop_loop_item' ); ?>
					</div>
					<div class="item-content">
						<h3><a href="<?php echo get_term_link( $term ); ?>"><?php echo $term->name; ?></h3>
						<h4><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute();?>"><?php the_title(); ?></a></h4>								
						<?php if ( $price_html = $product->get_price_html() ){?>
						<div class="item-price">
							<span>
								<?php echo $price_html; ?>
							</span>
						</div>
						<?php } ?>
						<!-- rating  -->
						<?php 
							$rating_count = $product->get_rating_count();
							$review_count = $product->get_review_count();
							$average      = $product->get_average_rating();
						?>
						<div class="reviews-content">
							<div class="star"><?php echo ( $average > 0 ) ?'<span style="width:'. ( $average*13 ).'px"></span>' : ''; ?></div>
						</div>						
					</div>			
				</div>
			<?php endwhile; wp_reset_postdata(); ?>
				
		<?php endif; ?>
	</div>
	<?php } ?>
	</div>
</div>	