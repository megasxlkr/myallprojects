<?php 
	if( $category == '' ){
		return '<div class="alert alert-warning alert-dismissible" role="alert">
			<a class="close" data-dismiss="alert">&times;</a>
			<p>'. esc_html__( 'Please select a category for SW Woocommerce Category Slider. Layout ', 'sw_woocommerce' ) . $layout .'</p>
		</div>';
	}
	if( !is_array( $category ) ){
		$category = explode( ',', $category );
	}
	$widget_id = isset( $widget_id ) ? $widget_id : 'category_slide_'.rand().time();
?>
<div id="<?php echo $widget_id; ?>" class="categories-mobile">
	<?php 
		if( $title1 != '' ){
				$titles = strpos($title1, ' ');
	?>
	<div class="box-slider-title">
		<?php 
			if( $titles ) : 
				echo '<h2><span>' . substr( $title1, 0, $titles ) . ' </span>' . substr( $title1, $titles + 1 ) .'</h2>'; 
			else: 
				echo '<h2><span>' . substr( $title1, 0, 1 ) . '</span>' . substr( $title1, 1 ) .'</h2>'; 
			endif;
		?>
	</div>
	<?php } ?>
	<div class="resp-slider-container">
		<div class="items-wrapper">
		<?php
			foreach( $category as $cat ){
				$term = get_term_by('slug', $cat, 'product_cat');	
				if( $term ) :
				$thumbnail_id 	= absint( get_term_meta( $term->term_id, 'thumbnail_id1', true ));
				$thumb = wp_get_attachment_image( $thumbnail_id,'full' );
		?>
			<div class="item item-product-cat">		
				<div class="item-in">			
					<div class="item-image">
						<a href="<?php echo get_term_link( $term->term_id, 'product_cat' ); ?>" title="<?php echo esc_attr( $term->name ); ?>"><?php echo $thumb; ?></a>
					</div>
					<div class="item-content">
						<h3><a href="<?php echo get_term_link( $term->term_id, 'product_cat' ); ?>"><?php echo $term->name; ?></a></h3>
					</div>
				</div>
			</div>
			<?php endif; ?>
		<?php } ?>
		</div>
	</div>
</div>		
		