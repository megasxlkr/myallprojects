<?php 
	/**
		** Theme: Responsive Slider
		** Author: Smartaddons
		** Version: 1.0
	**/
	$default = array(
			'category' => $category, 
			'orderby' => $orderby,
			'order' => $order, 
			'numberposts' => $numberposts,
	);
	$list = get_posts($default);
	do_action( 'before' ); 
	$id = 'sw_reponsive_post_slider_'.rand().time();
	if ( count($list) > 0 ){
?>
<div class="clear"></div>
<div id="<?php echo esc_attr( $id ) ?>" class="responsive-post-slider responsive-slider clearfix loading" data-lg="<?php echo esc_attr( $columns ); ?>" data-md="<?php echo esc_attr( $columns1 ); ?>" data-sm="<?php echo esc_attr( $columns2 ); ?>" data-xs="<?php echo esc_attr( $columns3 ); ?>" data-mobile="<?php echo esc_attr( $columns4 ); ?>" data-speed="<?php echo esc_attr( $speed ); ?>" data-scroll="<?php echo esc_attr( $scroll ); ?>" data-interval="<?php echo esc_attr( $interval ); ?>" data-autoplay="<?php echo esc_attr( $autoplay ); ?>">
	<div class="resp-slider-container">
		<?php 
			if( $title2 != '' ){
					$titles = strpos($title2, ' ');
		?>
		<div class="box-slider-title"><h2><?php echo  '<span>' . substr( $title2, 0, $titles ) . '</span> ' . substr( $title2, $titles + 1 ) ; ?></h2></div>
		<?php } ?>
		<div class="rows"> 
			<div class="slider responsive">
				<?php 	$i 	= 0;
						$count_items 	= 0;
						$numb 			= count( $list);
						$count_items 	= ( $numberposts >= $numb ) ? $numb : $numberposts;
				?>
				<?php foreach ($list as $post){ 
					if (has_post_format('video', $post)) {
						$icon = 'icon-facetime-video';
					}
					elseif (has_post_format('aside', $post)) {
						$icon = 'icon-edit';
					}
					elseif (has_post_format('audio', $post)) {
						$icon = 'icon-volume-down';
					}
					elseif (has_post_format('quote', $post)) {
						$icon = 'icon-quote-left';
					}
					elseif (has_post_format('status', $post)) {
						$icon = 'icon-comment';
					}
					elseif (has_post_format('chat', $post)) {
						$icon = 'icon-comments';
					}
					elseif (has_post_format(array('image', 'gallery'), $post)) {
						$icon = 'icon-picture';
					
								
					}else $icon = 'icon-pencil';
				?>
					<?php 
						if( $i % $item_row == 0 ){
						$class = ( $i % 2 == 0 ) ? ''  : 'item-odd';
					?>
					<div class="item widget-pformat-detail <?php echo esc_attr( $class ); ?>">
					<?php } ?>	
						<div class="blog-item pull-left">
							<div class="latest-blog-inner clearfix">
								<div class="widget-thumb pull-left">
									<a href="<?php the_permalink($post->ID); ?>" title="<?php echo esc_attr( $post->post_title ); ?>"><?php echo get_the_post_thumbnail($post->ID, 'furnicom_lastest_blog'); ?></a>
									<div class="entry-date">
										<div class="day-post"><?php echo get_the_time('j', $post->ID ); ?></div>
										<div class="mon-post"><?php echo get_the_time('M', $post->ID ); ?></div>
									</div>
								</div>
								<div class="widget-content-wrap">
									<div class="widget-content">
										<div class="item-title">
											<h4><a href="<?php the_permalink($post->ID); ?>" title="<?php echo esc_attr( $post->post_title ); ?>"><?php echo get_the_title( $post->ID );  ?></a></h4>
										</div>
										<div class="item-content">
											<p>
												<?php 
													$content = '';
													if( get_the_excerpt( $post->ID ) != '' ){
														$content = wp_trim_words(get_the_excerpt( $post->ID ), $length, ' ');
													}
													else if ( preg_match('/<!--more(.*?)?-->/', $post->post_content, $matches) ) {
													$content = explode($matches[0], $post->post_content, 2);
													$content =  wp_trim_words($content[0], $length, ' ');
													} else {
														$content = wp_trim_words($post->post_content, $length, ' ');
													}
													echo esc_html( $content ); 
												?>
											</p>
										</div>
										<div class="bl_read_more"><a href="<?php the_permalink($post->ID); ?>"><?php esc_html_e('Read more','sw-responsive-post-slider')?><i class="fa fa-angle-double-right"></i></a></div>
									</div>
								</div>
							</div>
						</div>
					<?php if( ( $i+1 ) % $item_row == 0 || ( $i+1 ) == $count_items ){?> </div><?php } ?>
					<?php $i++; wp_reset_postdata();}?>
			</div>
		</div>
	</div>
</div>
<?php } ?>