<?php 
add_action( 'vc_before_init', 'YA_shortcodeVC' );
function YA_shortcodeVC(){
$target_arr = array(
	__( 'Same window', 'sw_core' ) => '_self',
	__( 'New window', 'sw_core' ) => "_blank"
);
$link_category = array();
$link_cats     = get_categories();
if ( is_array( $link_cats ) ) {
	$link_category = array( __( 'All Category', 'sw_core' ) => '' );
	foreach ( $link_cats as $link_cat ) {
		$link_category[ $link_cat->name ] = $link_cat->slug;
	}
}
$menu_locations_array = array( __( 'All Links', 'sw_core' ) => '' );
$menu_locations = wp_get_nav_menus();	
foreach ($menu_locations as $menu_location){
	$menu_locations_array[$menu_location->name] = $menu_location -> term_id;
}
//YTC post
vc_map( array(
	'name' =>  __( 'Sw Posts', 'sw_core' ),
	'base' => 'sw_post',
	'icon' => 'icon-wpb-ytc',
	'category' => __( 'My shortcodes', 'sw_core' ),
	'class' => 'wpb_vc_wp_widget',
	'weight' => - 50,
	'description' => __( 'Display posts-seclect category', 'sw_core' ),
	'params' => array(
		array(
			'type' => 'textfield',
			'heading' => __( 'Widget title', 'sw_core' ),
			'param_name' => 'title',
			'description' => __( 'What text use as a widget title. Leave blank to use default widget title.', 'sw_core' )
		),
		array(
			'type' => 'textfield',
			'heading' => __( 'Description', 'sw_core' ),
			'param_name' => 'description',
			'description' => __( 'Description', 'sw_core' )
		),
		array(
			'type' => 'dropdown',
			'heading' => __( 'Layout', 'sw_core' ),
			'param_name' => 'layout',
			'value' => array(
				'Select type',
				__( 'Latest Blog', 'sw_core' ) => 'latest_blog',
				__( 'Latest News', 'sw_core' ) => 'latest_news',

			),
			'description' => sprintf( __( 'Select different layout posts.', 'sw_core' ), '<a href="http://codex.wordpress.org/Class_Reference/WP_Query#Order_.26_Orderby_Parameters" target="_blank">WordPress codex page</a>' )
		),
		array(
			'param_name'    => 'category_id',
			'type'          => 'dropdown',
			'value'         => $link_category, // here I'm stuck
			'heading'       => __('Select Category:', 'overmax'),
			'description'   => '',
			'holder'        => 'div',
			'class'         => ''
		),
		array(
			'type' => 'textfield',
			'heading' => __( 'Number of posts to show', 'sw_core' ),
			'param_name' => 'number',
			'admin_label' => true
		),
		array(
			'type' => 'textfield',
			'heading' => __( 'Excerpt length (in words)', 'sw_core' ),
			'param_name' => 'length',
			'description' => __( 'Excerpt length (in words).', 'sw_core' )
		),
		array(
			'type' => 'textfield',
			'heading' => __( 'Extra class name', 'sw_core' ),
			'param_name' => 'el_class',
			'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'sw_core' )
		),
			

		array(
			'type' => 'dropdown',
			'heading' => __( 'Order way', 'sw_core' ),
			'param_name' => 'order',
			'value' => array(
				__( 'Descending', 'sw_core' ) => 'DESC',
				__( 'Ascending', 'sw_core' ) => 'ASC'
			),
			'description' => sprintf( __( 'Designates the ascending or descending order. More at %s.', 'sw_core' ), '<a href="http://codex.wordpress.org/Class_Reference/WP_Query#Order_.26_Orderby_Parameters" target="_blank">WordPress codex page</a>' )
		),
				
		array(
			'type' => 'dropdown',
			'heading' => __( 'Order by', 'sw_core' ),
			'param_name' => 'orderby',
			'value' => array(
				'Select orderby',
				__( 'Date', 'sw_core' ) => 'date',
				__( 'ID', 'sw_core' ) => 'ID',
				__( 'Author', 'sw_core' ) => 'author',
				__( 'Title', 'sw_core' ) => 'title',
				__( 'Modified', 'sw_core' ) => 'modified',
				__( 'Random', 'sw_core' ) => 'rand',
				__( 'Comment count', 'sw_core' ) => 'comment_count',
				__( 'Menu order', 'sw_core' ) => 'menu_order'
			),
			'description' => sprintf( __( 'Select how to sort retrieved posts. More at %s.', 'sw_core' ), '<a href="http://codex.wordpress.org/Class_Reference/WP_Query#Order_.26_Orderby_Parameters" target="_blank">WordPress codex page</a>' )
		),
			
	)
) );
/* YTC VC */
// ytc tesminial

vc_map( array(
	'name' => 'Ya_ ' . __( 'Testimonial Slide', 'sw_core' ),
	'base' => 'testimonial_slide',
	'icon' => get_template_directory_uri() . "/assets/img/icon_vc.png",
	'category' => __( 'Ya Shortcode', 'sw_core' ),
	'class' => 'wpb_vc_wp_widget',
	'weight' => - 50,
	'description' => __( 'The tesminial on your site', 'sw_core' ),
	'params' => array(
		array(
			'type' => 'textfield',
			'heading' => __( 'Widget title', 'sw_core' ),
			'param_name' => 'title',
			'description' => __( 'What text use as a widget title. Leave blank to use default widget title.', 'sw_core' )
		),
		array(
			'type' => 'textfield',
			'heading' => __( 'Number of posts to show', 'sw_core' ),
			'param_name' => 'numberposts',
			'admin_label' => true
		),
		array(
			'type' => 'textfield',
			'heading' => __( 'Excerpt length (in words)', 'sw_core' ),
			'param_name' => 'length',
			'description' => __( 'Excerpt length (in words).', 'sw_core' )
		),
		array(
			'type' => 'dropdown',
			'heading' => __( 'Template', 'sw_core' ),
			'param_name' => 'type',
			'value' => array(
			    __('Indicators Up','sw_core') => 'indicators_up',
				__( 'indicators', 'sw_core' ) => 'indicators',
				__( 'Slide Style 1', 'sw_core' ) => 'style1',
				__('Slide Style 2','sw_core') => 'style2',
			),
			'description' => sprintf( __( 'Chose template for testimonial', 'sw_core' ) )
		),
		array(
			'type' => 'dropdown',
			'heading' => __( 'Order way', 'sw_core' ),
			'param_name' => 'order',
			'value' => array(
				__( 'Descending', 'sw_core' ) => 'DESC',
				__( 'Ascending', 'sw_core' ) => 'ASC'
			),
			'description' => sprintf( __( 'Designates the ascending or descending order. More at %s.', 'sw_core' ), '<a href="http://codex.wordpress.org/Class_Reference/WP_Query#Order_.26_Orderby_Parameters" target="_blank">WordPress codex page</a>' )
		),
				
		array(
			'type' => 'dropdown',
			'heading' => __( 'Order by', 'sw_core' ),
			'param_name' => 'orderby',
			'value' => array(
				'Select orderby',
				__( 'Date', 'sw_core' ) => 'date',
				__( 'ID', 'sw_core' ) => 'ID',
				__( 'Author', 'sw_core' ) => 'author',
				__( 'Title', 'sw_core' ) => 'title',
				__( 'Modified', 'sw_core' ) => 'modified',
				__( 'Random', 'sw_core' ) => 'rand',
				__( 'Comment count', 'sw_core' ) => 'comment_count',
				__( 'Menu order', 'sw_core' ) => 'menu_order'
			),
			'description' => sprintf( __( 'Select how to sort retrieved posts. More at %s.', 'sw_core' ), '<a href="http://codex.wordpress.org/Class_Reference/WP_Query#Order_.26_Orderby_Parameters" target="_blank">WordPress codex page</a>' )
		),
			
		array(
			'type' => 'textfield',
			'heading' => __( 'Extra class name', 'sw_core' ),
			'param_name' => 'el_class',
			'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'sw_core' )
		)
	)
) );

//ytc our brand
vc_map( array(
	'name' => 'YTC_ ' . __( 'Brand', 'sw_core' ),
	'base' => 'OurBrand',
	'icon' => 'icon-wpb-ytc',
	'category' => __( 'My shortcodes', 'sw_core' ),
	'class' => 'wpb_vc_wp_widget',
	'weight' => - 50,
	'description' => __( 'The best sale  product on your site', 'sw_core' ),
	'params' => array(
		array(
			'type' => 'textfield',
			'heading' => __( 'Widget title', 'sw_core' ),
			'param_name' => 'title',
			'description' => __( 'What text use as a widget title. Leave blank to use default widget title.', 'sw_core' )
		),
		array(
			'type' => 'dropdown',
			'heading' => __( 'Style title', 'sw_core' ),
			'param_name' => 'style_title',
			'value' => array(
				'Select type',
				__( 'Style title 1', 'sw_core' ) => 'title1',
				__( 'Style title 2', 'sw_core' ) => 'title2',
				__( 'Style title 3', 'sw_core' ) => 'title3',
				__( 'Style title 4', 'sw_core' ) => 'title4'
			),
			'description' =>__( 'What text use as a style title. Leave blank to use default style title.', 'sw_core' )
		),
		array(
			'type' => 'dropdown',
			'heading' => __( 'Type display', 'sw_core' ),
			'param_name' => 'type',
			'value' => array(
				'Select type',
				__( 'Type default', 'sw_core' ) => 'default',
				__( 'Type slide', 'sw_core' ) => 'slide',
			),
			'description' =>__( 'type you want display.', 'sw_core' )
		),
		array(
			'type' => 'textfield',
			'heading' => __( 'Number of posts to show', 'sw_core' ),
			'param_name' => 'numberposts',
			'admin_label' => true
		),
		array(
			'type' => 'dropdown',
			'heading' => __( 'Order way', 'sw_core' ),
			'param_name' => 'order',
			'value' => array(
				__( 'Descending', 'sw_core' ) => 'DESC',
				__( 'Ascending', 'sw_core' ) => 'ASC'
			),
			'description' => __( 'Designates the ascending or descending order. More at %s.', 'sw_core' )
		),
				
		array(
			'type' => 'dropdown',
			'heading' => __( 'Order by', 'sw_core' ),
			'param_name' => 'orderby',
			'value' => array(
				'Select orderby',
				__( 'Date', 'sw_core' ) => 'date',
				__( 'ID', 'sw_core' ) => 'ID',
				__( 'Author', 'sw_core' ) => 'author',
				__( 'Title', 'sw_core' ) => 'title',
				__( 'Modified', 'sw_core' ) => 'modified',
				__( 'Random', 'sw_core' ) => 'rand',
				__( 'Comment count', 'sw_core' ) => 'comment_count',
				__( 'Menu order', 'sw_core' ) => 'menu_order'
			),
			'description' => __( 'Select how to sort retrieved posts. More at %s.', 'sw_core' )
		),
		array(
			'type' => 'textfield',
			'heading' => __( 'Speed slide', 'sw_core' ),
			'param_name' => 'interval',
			'description' => __( 'Speed for slide', 'sw_core' )
		),
		array(
			'type' => 'dropdown',
		    'heading' => __( 'Effect slide', 'sw_core' ),
			'param_name' => 'effect',
			'value' => array(
				__( 'Slide', 'sw_core' ) => 'slide',
				__( 'Fade', 'sw_core' ) => 'fade',
			),
				'description' => __( 'Effect for slide', 'sw_core' )
		),
		array(
			'type' => 'dropdown',
		    'heading' => __( 'Hover slide', 'sw_core' ),
			'param_name' => 'hover',
			'value' => array(
				__( 'Yes', 'sw_core' ) => 'hover',
				__( 'No', 'sw_core' ) => '',
			),
				'description' => __( 'Hover for slide', 'sw_core' )
		),
		array(
			'type' => 'dropdown',
		    'heading' => __( 'Swipe slide', 'sw_core' ),
			'param_name' => 'swipe',
			'value' => array(
				__( 'Yes', 'sw_core' ) => 'yes',
				__( 'No', 'sw_core' ) => 'no',
			),
				'description' => __( 'Swipe for slide', 'sw_core' )
		),
		array(
			'type' => 'textfield',
			'heading' => __( 'Number of Columns >1200px:', 'sw_core' ),
			'param_name' => 'columns',
			'description' => __( 'Number colums you want display  > 1200px.', 'sw_core' )
		),
		array(
			'type' => 'textfield',
			'heading' => __( 'Number of Columns on 768px to 1199px:', 'sw_core' ),
			'param_name' => 'columns1',
			'description' => __( 'Number colums you want display  on 768px to 1199px.', 'sw_core' )
		),
		array(
			'type' => 'textfield',
			'heading' => __( 'Number of Columns on 480px to 767px:', 'sw_core' ),
			'param_name' => 'columns2',
			'description' => __( 'Number colums you want display  on 480px to 767px.', 'sw_core' )
		),
		array(
			'type' => 'textfield',
			'heading' => __( 'Number of Columns on 321px to 479px:', 'sw_core' ),
			'param_name' => 'columns3',
			'description' => __( 'Number colums you want display  on 321px to 479px.', 'sw_core' )
		),
		array(
			'type' => 'textfield',
			'heading' => __( 'Number of Columns in 320px or less than:', 'sw_core' ),
			'param_name' => 'columns4',
			'description' => __( 'Number colums you want display  in 320px or less than.', 'sw_core' )
		),
		array(
			'type' => 'textfield',
			'heading' => __( 'Extra class name', 'sw_core' ),
			'param_name' => 'el_class',
			'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'sw_core' )
		)
	)
) );
//// vertical mega menu
vc_map( array(
	'name' => 'YTC ' . __( 'vertical mega menu', 'sw_core' ),
	'base' => 'furnicom_mega_menu',
	'icon' => 'icon-wpb-ytc',
	'category' => __( 'My shortcodes', 'sw_core' ),
	'class' => 'wpb_vc_wp_widget',
	'weight' => - 50,
	'description' => __( 'Display vertical mega menu', 'sw_core' ),
	'params' => array(
	    array(
			'type' => 'textfield',
			'heading' => __( 'Widget title', 'sw_core' ),
			'param_name' => 'title',
			'description' => __( 'What text use as a widget title. Leave blank to use default widget title.', 'sw_core' )
		),
		array(
			'param_name'    => 'style',
			'type'          => 'dropdown',
			'value'         => array(
				'Style Default' => '',
				'Style 1'       => 'style1'
			), // here I'm stuck
			'heading'       => __('Style Vertical Menu', 'sw_core'),
			'description'   => '',
			'holder'        => 'div'
		),
	    array(
			'param_name'    => 'menu_locate',
			'type'          => 'dropdown',
			'value'         => $menu_locations_array, // here I'm stuck
			'heading'       => __('Category menu:', 'overmax'),
			'description'   => '',
			'holder'        => 'div',
			'class'         => ''
		),
		array(
			'type' => 'dropdown',
			'heading' => __( 'Theme shortcode want display', 'sw_core' ),
			'param_name' => 'widget_template',
			'value' => array(
				__( 'default', 'sw_core' ) => 'default',
			),
			'description' => sprintf( __( 'Select different style menu.', 'sw_core' ) )
		),
		array(
			'type' => 'textfield',
			'heading' => __( 'Extra class name', 'sw_core' ),
			'param_name' => 'el_class',
			'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'sw_core' )
		),			
	)
));

///// Gallery 
vc_map( array(
	'name' => __( 'YTC_Gallery', 'sw_core' ),
	'base' => 'gallerys',
	'icon' => 'icon-wpb-images-carousel',
	'category' => __( 'My shortcodes', 'sw_core' ),
	'description' => __( 'Animated carousel with images', 'sw_core' ),
	'params' => array(
		array(
			'type' => 'textfield',
			'heading' => __( 'Widget title', 'sw_core' ),
			'param_name' => 'title',
			'description' => __( 'Enter text which will be used as widget title. Leave blank if no title is needed.', 'sw_core' )
		),
		array(
			'type' => 'attach_images',
			'heading' => __( 'Images', 'sw_core' ),
			'param_name' => 'ids',
			'value' => '',
			'description' => __( 'Select images from media library.', 'sw_core' )
		),
		array(
			'type' => 'textfield',
			'heading' => __( 'gallery size', 'sw_core' ),
			'param_name' => 'size',
			'description' => __( 'Enter image size. Example: thumbnail, medium, large, full or other sizes defined by current theme. Alternatively enter image size in pixels: 200x100 (Width x Height). Leave empty to use "thumbnail" size. If used slides per view, this will be used to define carousel wrapper size.', 'sw_core' )
		),
		
		array(
			'type' => 'dropdown',
			'heading' => __( 'Gallery caption', 'sw_core' ),
			'param_name' => 'caption',
			'value' => array(
				__( 'true', 'sw_core' ) => 'true',
				__( 'false', 'sw_core' ) => 'false'
			),
			'description' => __( 'Images display caption true or false', 'sw_core' )
		),
		array(
			'type' => 'dropdown',
			'heading' => __( 'Gallery type', 'sw_core' ),
			'param_name' => 'type',
			'value' => array(
				__( 'column', 'sw_core' ) => 'column',
				__( 'slide', 'sw_core' ) => 'slide',
				__( 'flex', 'sw_core' ) => 'flex'
			),
			'description' => __( 'Images display type', 'sw_core' )
		),
		array(
			'type' => 'textfield',
			'heading' => __( 'gallery columns', 'sw_core' ),
			'param_name' => 'columns',
			'description' => __( 'Enter gallery columns. Example: 1,2,3,4 ... Only use gallery type="column".', 'sw_core' )
		),
		array(
			'type' => 'textfield',
			'heading' => __( 'Slider speed', 'sw_core' ),
			'param_name' => 'interval',
			'value' => '5000',
			'description' => __( 'Duration of animation between slides (in ms)', 'sw_core' )
		),
		array(
			'type' => 'dropdown',
			'heading' => __( 'Gallery event', 'sw_core' ),
			'param_name' => 'event',
			'value' => array(
				__( 'slide', 'sw_core' ) => 'slide',
				__( 'fade', 'sw_core' ) => 'fade'
			),
			'description' => __( 'event slide images', 'sw_core' )
		),
		array(
			'type' => 'textfield',
			'heading' => __( 'Extra class name', 'sw_core' ),
			'param_name' => 'class',
			'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'sw_core' )
		)
		)
) );
vc_map( array(
  "name" => __( "Furnicom IMG Slider", "sw_core" ),
  "base" => "img_slide",
  "icon" => "icon-wpb-ytc",
  "class" => "",
  "category" => __( "My shortcodes", "sw_core"),
  "params" => array(
	 array(
		"type" => "textfield",
		"holder" => "div",
		"class" => "",
		"heading" => __( "Title", "sw_core" ),
		"param_name" => "title",
		"value" => __( "", "sw_core" ),
		"description" => __( "Title", "sw_core" )
	 ),
	 array(
		'type' => 'attach_images',
		'heading' => __( 'Images', 'destino' ),
		'param_name' => 'ids',
		'value' => '',
		'description' => __( 'Select images from media library.', 'destino' )
	),
	 array(
		"type" => "dropdown",
		"holder" => "div",
		"class" => "",
		"heading" => __( "Fade", "sw_core" ),
		"param_name" => "fade",
		"value" => array( 'True' => 'true', 'False' => 'false' ),
		"description" => __( "Fade", "sw_core" )
	 ),
	  array(
		"type" => "dropdown",
		"holder" => "div",
		"class" => "",
		"heading" => __( "Dots", "sw_core" ),
		"param_name" => "dots",
		"value" => array( 'True' => 'true', 'False' => 'false' ),
		"description" => __( "Dots", "sw_core" )
	 ),
	 array(
		"type" => "textfield",
		"holder" => "div",
		"class" => "",
		"heading" => __( "Speed", "sw_core" ),
		"param_name" => "autoplaySpeed",
		"value" => 1000,
		"description" => __( "Speed Of Slide", "sw_core" )
	 ),
	 array(
		"type" => "dropdown",
		"holder" => "div",
		"class" => "",
		"heading" => __( "Auto Play", "sw_core" ),
		"param_name" => "autoplay",
		"value" => array( 'True' => 'true', 'False' => 'false' ),
		"description" => __( "Auto Play", "sw_core" )
	 ),
	 array(
		"type" => "textfield",
		"holder" => "div",
		"class" => "",
		"heading" => __( "Interval", "sw_core" ),
		"param_name" => "interval",
		"value" => 5000,
		"description" => __( "Interval", "sw_core" )
	 ),
  )
) );
}
?>