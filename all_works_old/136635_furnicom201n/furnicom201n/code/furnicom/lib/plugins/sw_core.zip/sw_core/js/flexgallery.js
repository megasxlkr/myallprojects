(function($) {
  "use strict";
  var $furnicom_event = furnicom_flexgallery.event;
  var $furnicom_event_thumbnail = furnicom_flexgallery.evthumbnail;
	jQuery(document).ready(function(){
	  jQuery("#flex-thumbnail").flexslider({
		animation: 'slide',
		controlNav: false,
		itemMargin: 10,
		animationLoop: false,
		slideshow: false,
		itemWidth: 113,				
		asNavFor: "#flexslider-gallery"
	  });

	  jQuery("#flexslider-gallery").flexslider({
		animation:$furnicom_event,
		controlNav: false,
		animationLoop: true,
		slideshow: true,
		sync: "#flex-thumbnail",
		start: function(slider){
		  jQuery("body").removeClass("loading");
		}
	  });
	  jQuery('.gallery-images').removeClass('slider-loading');
	});
})(jQuery);