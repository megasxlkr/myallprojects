<?php
/**
 * Plugin Name: SW Core
 * Plugin URI: http://smartaddons.com
 * Description: A plugin developed for many shortcode in theme
 * Version: 1.1.4
 * Author: smartaddons.com
 * Author URI: http://smartaddons.com
 *
 * This Widget help you to show images of product as a beauty reponsive slider
 */
 
if ( ! defined( 'ABSPATH' ) ) {
	exit; 
}

if( !function_exists( 'is_plugin_active' ) ){
	include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
}
/* define plugin path */
if ( ! defined( 'SWPATH' ) ) {
	define( 'SWPATH', plugin_dir_path( __FILE__ ) );
}
/* define plugin URL */
if ( ! defined( 'SWURL' ) ) {
	define( 'SWURL', plugins_url(). '/sw_core' );
}

function sw_core_construct(){
	require_once( SWPATH . 'posts/sw-post-shortcode.php' );
	require_once( SWPATH . 'sw_plugins/sw-plugins.php' );
	require_once( SWPATH . 'countdown.php' );
	require_once( SWPATH . 'skills.php' );
	require_once( SWPATH . 'gallery.php' );
	require_once( SWPATH . 'img-slide.php' );
	if( is_plugin_active( 'js_composer/js_composer.php' ) ){
		require_once ( SWPATH . '/visual-map.php' );
	}
	load_plugin_textdomain( 'sw_core', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' ); 
	add_action( 'wp_enqueue_scripts', 'Sw_AddScript', 20 );
}
add_action( 'plugins_loaded', 'sw_core_construct', 20 );


function Sw_AddScript(){
	wp_register_style('furnicom_photobox_css', plugins_url( '/css/photobox.css', __FILE__ ), array(), null);	
	wp_register_style('flexslider_css', plugins_url( '/css/flexslider.css', __FILE__ ), array(), null);
	wp_register_style('lightbox_css', plugins_url( '/css/jquery.fancybox.css', __FILE__ ), array(), null);
	wp_register_style('shortcode_css', plugins_url( '/css/shortcodes.css', __FILE__ ), array(), null);
	wp_register_style('prettyPhoto_css', plugins_url( '/css/prettyPhoto.css', __FILE__ ), array(), null);
    wp_register_script('flexslider_js', plugins_url( '/js/jquery.flexslider-min.js', __FILE__ ), array(), null, true);
	wp_register_script('photobox_js', plugins_url( '/js/photobox.js', __FILE__ ), array(), null, true);
	wp_register_script('counter_js', plugins_url( '/js/jquery.counterup.js', __FILE__ ), array(), null, true);
	wp_register_script('prettyPhoto', plugins_url( '/js/jquery.prettyPhoto.js', __FILE__ ), array(), null, true);
	wp_register_script('lightbox_js', plugins_url( '/js/jquery.fancybox.pack.js', __FILE__ ), array(), null, true);
	wp_register_script('countdown', plugins_url( '/js/jquery.classycountdown.min.js', __FILE__ ), array(), null, true);
	wp_enqueue_style( 'lightbox_css' );
	wp_enqueue_style( 'prettyPhoto_css' );
	wp_enqueue_style( 'shortcode_css' );
	wp_enqueue_script( 'countdown' );	
	wp_enqueue_script( 'lightbox_js' );	
	wp_enqueue_script( 'flexslider_js' );	
	wp_enqueue_script( 'counter_js' );	
	if( !wp_script_is( 'prettyPhoto' ) ){
		wp_enqueue_script( 'prettyPhoto' );	
	}	
	if( !wp_style_is( 'woocommerce_prettyPhoto_css' ) ){
		wp_enqueue_script( 'prettyPhoto_css' );	
	}
}


class YA_Shortcodes{
	protected $supports = array();

	protected $tags = array( 'icon','videos', 'button', 'alert', 'bloginfo', 'colorset', 'slideshow', 'googlemaps', 'tabs', 'collapses', 'columns', 'row', 'col', 'code', 'breadcrumb', 'pricing','tooltip','modal','gallery_image');

	public function __construct(){
		$this->add_shortcodes();
	}
	
	public function add_shortcodes(){
		if ( is_array($this->tags) && count($this->tags) ){
			foreach ( $this->tags as $tag ){
				add_shortcode($tag, array($this, $tag));
			}
		}
	}
	
	function code($attr, $content) {
		$html = '';
		$html .= '<pre>';
		$html .= $content;
		$html .= '</pre>';
		
		return $html;
	}
	
	function icon( $atts ) {
		
		// Attributes
		extract( shortcode_atts(
			array(
				'tag' => 'span',
				'name' => '*',
				'class' => '',
				'border'=>'',
				'bg'    =>'',
				'color' => ''
			), $atts )
		);
		$attributes = array();
	
		$classes = preg_split('/[\s,]+/', $class, -1, PREG_SPLIT_NO_EMPTY);
		
		if ( !preg_match('/fa-/', $name) ){
			$name = 'fa-'.$name;
		}
		array_unshift($classes, $name);
		
		$classes = array_unique($classes);
		
		$attributes[] = 'class="fa '.implode(' ', $classes).'"';
		if(!empty($color)&&!empty($bg)&&!empty($border)){
			$attributes[] = 'style="color: '.$color.';background:'.$bg.';border:1px solid '.$border.'"';
		}
		if ( !empty($color) ){
			$attributes[] = 'style="color: '.$color.'"';
		}
		
		// Code
		return "<$tag ".implode(' ', $attributes)."></$tag>";
	}
	
	public function button( $atts, $content = null ){
		// Attributes
		extract( shortcode_atts(
			array(
				'id' => '',
				'tag' => 'span',
				'class' => 'btn',
				'target' => '',
				'type' => 'default',
				'border' =>'',
				'color' =>'',
				'size'	=> '',
				'icon' => '',
				'href' => '#'
			), $atts )
		);
		$attributes = array();
		
		$classes = $class;
		if ( $type != '' ){
			$type = ' btn-'.$type;
		}
		if( $size != '' ){
			$size = 'btn-'.$size;
		}
		$classes .= $type.' '.$size;
		$attributes[] = 'class="'.$classes.'"';
		if ( !empty($id) ){
			$attributes[] = 'id="'.esc_attr($id).'"';
		}
		if ( !empty($target) ){
			if ( 'a' == $tag ){
				$attributes[] = 'target="'.esc_attr($target).'"';
			} else {
				// html5
				$attributes[] = 'data-target="'.esc_attr($target).'"';
			}
		}
		
		if ( 'a' == $tag ){
			$attributes[] = 'href="'.esc_attr($href).'"';
		}
		if( $icon != '' ){
			$icon = '<i class="'.$icon.'"></i>';
		}
		return "<$tag ".implode(' ', $attributes).">".$icon."".do_shortcode($content)."</$tag>";
	}
	
	/**
	 * Alert
	 * */
	public function alert($atts, $content = null ){

		extract(shortcode_atts(array(
				'tag' => 'div',
				'class' => 'block',
				'dismiss' => 'true',
				'icon'  => '',
				'color'	=> '',
				'border' => '',
				'type' => ''
			), $atts)
		);
		
		$attributes = array();
		$attributes[] = $tag;
		$classes = array();
		$classes = preg_split('/[\s,]+/', $class, -1, PREG_SPLIT_NO_EMPTY);
		
		if ( !preg_match('/alert-/', $type) ){
			$type = 'alert-'.$type;
		}
		if( $color != '' || $border != '' ){
			$attributes[] .= 'style="color: '.$color.'; border-color:'.$border.'"';
		}
		array_unshift($classes, 'alert', $type);
		$classes = array_unique($classes);
		$attributes[] = 'class="'.implode(' ', $classes).'"';
		
		$html = '';
		$html .= '<'.implode(' ', $attributes).'>';
		if( $icon != '' ){
			$html .= '<i class="'.$icon.'"></i>';
		}
		if ($dismiss == 'true') {
			$html .= '<button type="button" class="close" data-dismiss="alert">&times;</button>';
		}
		$html .= do_shortcode($content);
		$html .= '</'.$tag.'>';
		return $html;
	}


	/**
	 * Bloginfo
	 * */
	function bloginfo( $atts){
		extract( shortcode_atts(array(
				'show' => 'wpurl',
				'filter' => 'raw'
			), $atts)
		);
		$html = '';
		$html .= get_bloginfo($show, $filter);

		return $html;
	}
	
	function colorset($atts){
		$value = furnicom_options()->getCpanelValue('scheme'); 
		return $value;
	}
	
	/**
	 * Google Maps
	 */
	function googlemaps($atts, $content = null) {
		extract(shortcode_atts(array(
		"title" => '',
		"location" => '',
		"width" => '', //leave width blank for responsive designs
		"height" => '300',
		"zoom" => 10,
		"align" => '',
		), $atts));

		// load scripts
		wp_enqueue_script('furnicom_googlemap',  get_template_directory_uri() . '/js/furnicom_googlemap.js', array('jquery'), '', true);
		wp_enqueue_script('furnicom_googlemap_api', 'https://maps.googleapis.com/maps/api/js?sensor=false', array('jquery'), null, true);

		$output = '<div id="map_canvas_'.rand(1, 100).'" class="googlemap" style="height:'.$height.'px;width:'.$width.'">';
		$output .= (!empty($title)) ? '<input class="title" type="hidden" value="'.esc_attr( $title ).'" />' : '';
		$output .= '<input class="location" type="hidden" value="'.esc_attr( $location ).'" />';
		$output .= '<input class="zoom" type="hidden" value="'.esc_attr( $zoom ).'" />';
		$output .= '<div class="map_canvas"></div>';
		$output .= '</div>';

		return $output;
	}


	/**
	 * Tabs
	 * */
	public function tabs( $atts , $content = null ) {
		static $key = 0;
		
		if (is_array($atts) ) {
				
			foreach ($atts as $k => $att){
				$att = trim($att);
				if (empty($att)) unset( $atts[$k] );
			}
		}
		$yaTab_id = 'yaTab-'.$key;
		extract(shortcode_atts(array(
				'tag' => 'div',
				'class' => 'tabbable',
				'position' => 'top'
			), $atts));
		$atts['id'] = $yaTab_id;
		$classes = array();
		$classes = preg_split('/[\s,]+/', $class, -1, PREG_SPLIT_NO_EMPTY);
		array_unshift($classes, 'tabbable');
		
		if ( $position == 'left' ) array_unshift($classes, 'tabs-left');
		elseif ( $position == 'right' ) array_unshift($classes, 'tabs-right');
		elseif ($position == 'bottom') array_unshift($classes, 'tabs-below');
		
		$classes = array_unique($classes);
		$classes = ' class="'.implode(' ', $classes).'"';
		
		$html = '';
		$html .= '<'.$tag.$classes.' id="'.esc_attr( $yaTab_id ).'">';
		$html .= self::get_tab($atts, $content);
		$html .= '</'.$tag.'>';
		$key++;
		
		return $html;
	}
	
	
	protected function get_tab($atts, $content){
		
		if (preg_match_all('/\[(\[?)(tab)(?![\w-])([^\]\/]*(?:\/(?!\])[^\]\/]*)*?)(?:(\/)\]|\](?:([^\[]*+(?:\[(?!\/\2\])[^\[]*+)*+)\[\/\2\])?)(\]?)/', $content, $m)) {
			$titles = array();
			$contents = array();
			$icons = array();
			for ($i=0; $i<count($m[0]); $i++) {			
				preg_match_all("/title=&#8221;(.*)&[#8243;,#8221;]/iU", $m[3][$i], $output_title);
				preg_match_all("/icon=&#8221;(.*)&#8221;/iU", $m[3][$i], $output_icon);				
				extract(shortcode_atts( array(
									'title' => (count($output_title[1]) > 0 ) ?$output_title[1][0] : '',
									'icon'	=> (count($output_icon[1]) > 0 ) ? $output_icon[1][0] : ''
								), $atts
							)
						);
				$titles[] = $title;				
				$contents[] = $m[5][$i];
				$icons[] = '<i class="'.$icon.'"></i>';
			}
		
			$header = '<ul class="nav nav-tabs responsive">';
			foreach ($titles as $i => $title){
				$class = '';
				if ($i == 0) $class .= ' class="active"';
				$header .= '<li '.$class.'><a data-toggle="tab" href="#'.$atts['id'].$i.'">'.$icons[$i].esc_html( $title ).'</a></li>';
			}
			$header .= '</ul>';
			
			$body = '<div class="tab-content responsive">';
			foreach ($contents as $i => $content){
				$class = 'tab-pane';
				if ($i == 0) $class .= ' active';
				$class = 'class="'.$class.'"';
				$body .= '<div '.$class.' id="'.$atts['id'].$i.'">'.do_shortcode($content).'</div>';
			}
			$body .= '</div>';
			
			$html = '';
			if ($atts['position'] == 'bottom') {
				$html .= $body.$header;
			} else $html .= $header.$body;
		}
		
		return $html;
	}
	
	
	/**
	 * Collapse
	 * */

	public function collapses( $atts, $content = NULL ){
		static $key = 0;

		if (is_array($atts) ) {
				
			foreach ($atts as $k => $att){
				$att = trim($att);
				if (empty($att)) unset( $atts[$k] );
			}
		}

		$collapse_id = 'yaCollapse-'.$key ;
		extract(shortcode_atts(array(
				'class' => '',
				'type' => 'collapse',
				'tag'   => 'div'
			), $atts));
		$atts['id'] = $collapse_id;
		$classes = array();
		$classes = preg_split('/[\s,]+/', $class, -1, PREG_SPLIT_NO_EMPTY);
		array_unshift($classes, 'panel-group');
		$classes = array_unique($classes);
		$html = '';
		$html .= '<'.$tag.' id="'.esc_attr( $collapse_id ).'" class="'.implode(' ', $classes).'">';
		$html .= self::get_collapse($atts, $content);
		$html .= '</'.$tag.'>';
		$key++;
		
		return $html;
	}

	function get_collapse( $atts, $content = NULL ) {
		$html = '';
		if (preg_match_all('/\[(\[?)(collapse)(?![\w-])([^\]\/]*(?:\/(?!\])[^\]\/]*)*?)(?:(\/)\]|\](?:([^\[]*+(?:\[(?!\/\2\])[^\[]*+)*+)\[\/\2\])?)(\]?)/', $content, $m)) {
			$titles = array();
			$contents = array();
			for ($i=0; $i<count($m[0]); $i++) {			
				preg_match_all("/title=&#8221;(.*)&[#8243;,#8221;]/iU", $m[3][$i], $output_title);
				preg_match_all("/active=&#8221;(.*)&#8221;/iU", $m[3][$i], $output_class);
				extract(shortcode_atts( array(
				                
								'title' => (count($output_title[1]) > 0 ) ?$output_title[1][0] : '',
								'active' => (count($output_class[1]) > 0 ) ?$output_class[1][0] : ''
								
							), $atts
						)
					);
				$content = $m[5][$i];
				$attributes = ($active == 'true') ? 'class="panel-collapse collapse in" data-toggle="collapse" id="'.$atts['id'].$i.'"': 'class="panel-collapse collapse" id="'.$atts['id'].$i.'"';
				$types = ($active == 'true') ? 'class="accordion-toggle ya-accordion" data-toggle="collapse"' : 'class="accordion-toggle ya-accordion collapsed" data-toggle="collapse"';
				$types .= ( $atts['type'] == 'collapse' ) ? ' data-parent="#'.$atts['id'].'"' : '';
				$types .= ' href="#'.$atts['id'].$i.'"';
				$html .= '<div class="panel panel-default">';
				$html .= '<a '.$types.'><span></span><div class="panel-heading">'.esc_html( $title ).'</div></a>';
				$html .= '<div '.$attributes.'>
							<div class="panel-body">
								'.do_shortcode($content).'
							</div>
						</div>';
				$html .= '</div>';
			}
		}
		
		return $html;
	}

	
	/**
	 * Column
	 * */
	public function row( $atts, $content = null ){
		extract( shortcode_atts( array(
			'class' => '',
			'tag'   => 'div',
			'type'  => ''
		), $atts) );
		$row_class = 'row';
		
		$classes = array();
		$classes = preg_split('/[\s,]+/', $class, -1, PREG_SPLIT_NO_EMPTY);
		
		array_unshift($classes, $row_class);
		$classes = array_unique($classes);
		$classes = ' class="'. implode(' ', $classes).'"';
		return "<$tag ". $classes . ">" . do_shortcode($content) . "</$tag>";
	}
	
	public function col( $atts, $content = null ){
		extract( shortcode_atts( array(
			'class' 	=> '',
			'tag'   	=> 'div',
			'large'  	=> '12',
			'medium'	=> '12',
			'small'		=> '12',
			'xsmall'	=> '12'
		), $atts) );
		$col_class  = !empty($large)  ? "col-lg-$large"   : 'col-lg-12';
		$col_class .= !empty($medium) ? " col-md-$medium" : ' col-md-12';
		$col_class .= !empty($small)  ? " col-sm-$small"  : ' col-sm-12';
		$col_class .= !empty($xsmall) ? " col-xs-$xsmall" : ' col-xs-12';
		$classes = array();
		$classes = preg_split('/[\s,]+/', $class, -1, PREG_SPLIT_NO_EMPTY);
		array_unshift($classes, $col_class);
		$classes = array_unique($classes);
		$classes = ' class="'. implode(' ', $classes).'"';
		return "<$tag ". $classes . ">" . do_shortcode($content) . "</$tag>";
	}
	
	public function breadcrumb ($atts){
		
		extract(shortcode_atts(array(
				'class' => 'breadcumbs',
				'tag'  => 'div'
			), $atts));
			
		$classes = preg_split('/[\s,]+/', $class, -1, PREG_SPLIT_NO_EMPTY);
		$classes = ' class="' . implode(' ', $classes) . '" ';
		
		$before = '<' . $tag . $classes . '>';
		$after  = '</' . $tag . '>';
		
		$furnicom_breadcrumb = new YA_Breadcrumbs;
		return $furnicom_breadcrumb->breadcrumb( $before, $after, false );
	}
}
new YA_Shortcodes();


/*
 * Pricing Table
 * @since v1.0
 *
 */
 
/*main*/
if( !function_exists('furnicom_pricing_table_shortcode') ) {
	function furnicom_pricing_table_shortcode( $atts, $content = null  ) {
		extract( shortcode_atts( array(
			'style' => 'style1',
		), $atts ) );
		
	   return '<div class="pricing-table clearfix '.$style.'">' . do_shortcode($content) . '</div></div>';
	}
	add_shortcode( 'pricing_table', 'furnicom_pricing_table_shortcode' );
}

/*section*/
if( !function_exists('furnicom_pricing_shortcode') ) {
	function furnicom_pricing_shortcode( $atts, $content = null, $style_table) {
		
		extract( shortcode_atts( array(
			'style' =>'style1',
			'size' => 'one-five',
			'featured' => 'no',
			'description'=>'',
			'plan' => '',
			'cost' => '$20',
			'currency'=>'',
			'per' => 'month',
			'button_url' => '',
			'button_text' => 'Purchase',
			'button_target' => 'self',
			'button_rel' => 'nofollow'
		), $atts ) );
		
		//set variables
		$featured_pricing = ( $featured == 'yes' ) ? 'most-popular' : NULL;
		
		//start content1  
		$pricing_content1 ='';
		$pricing_content1 .= '<div class="pricing pricing-'. $size .' '. $featured_pricing . '">';
				$pricing_content1 .= '<div class="header">'. esc_html( $plan ). '</div>';
				$pricing_content1 .= '<div class="price">'. esc_html( $cost ) .'/'. esc_html( $per ) .'</div>';
			$pricing_content1 .= '<div class="pricing-content">';
				$pricing_content1 .= ''. $content. '';
			$pricing_content1 .= '</div>';
			if( $button_url ) {
				$pricing_content1 .= '<a href="'. esc_url( $button_url ) .'" class="signup" target="_'. esc_attr( $button_target ).'" rel="'. esc_attr( $button_rel ) .'" '.'>'. esc_html( $button_text ) .'</a>';
			}
		$pricing_content1 .= '</div>';
		//start content2  
		$pricing_content2 ='';
		$pricing_content2 .= '<div class="pricing pricing-'. $size .' '. $featured_pricing . '">';
			$pricing_content2 .= '<div class="header"><h3>'. esc_html( $plan ). '</h3><span>'.esc_html( $description ).'</span></div>';
				
			$pricing_content2 .= '<div class="pricing-content">';
				$pricing_content2 .= ''. $content. '';
			$pricing_content2 .= '</div>';
			$pricing_content2 .= '<div class="price"><span class="span-1"><p>'.$currency.'</p>'. esc_html( $cost ) .'</span><span class="span-2">'. esc_html( $per ) .'</span></div>';
			if( $button_url ) {
				$pricing_content2 .= '<div class="plan"><a href="'. esc_url( $button_url ) .'" class="signup" target="_'. esc_attr( $button_target ) .'" rel="'. esc_attr( $button_rel ) .'" '.'>'. esc_html( $button_text ) .'</a></div>';
			}
		$pricing_content2 .= '</div>';
		//start basic
		$pricing_content4 ='';
		$pricing_content4 .= '<div class="pricing pricing-'. $size .' '. $featured_pricing . '">';
			$pricing_content4 .= '<div class="price"><span class="span-1">'. esc_html( $cost ) .'<p>'.$currency.'</p></span><span class="span-2">'. esc_html( $per ) .'</span></div>';
			if( $button_url ) {
				$pricing_content4 .= '<div class="plan"><a href="'. esc_url( $button_url ) .'" class="signup" target="_'. esc_attr( $button_target ) .'" rel="'. esc_attr( $button_rel ) .'" '.'>'. esc_html( $button_text ) .'</a></div>';
			}
		$pricing_content4 .= '</div>';
		if($style == 'style1'||$style == 'style3'){
			return $pricing_content1;
		}
		if($style == 'style2') {
			return $pricing_content2;
		}
		if($style == 'basic'){
			return $pricing_content4;
		}
	}
	
	add_shortcode( 'pricing', 'furnicom_pricing_shortcode' );
}
/*
 * Tooltip
 * @since v1.0
 *
 */
 function furnicom_tooltip($atts, $content = null) {
            extract(shortcode_atts(array(
	 'info' =>'',
	 'title'=>'',
	 'style'=>'',
	 'position'=>''
	 ),$atts));
	 if($title !=''){
		$title = '<strong>'.$title.'</strong>';
	 }
		  $html ='<a class="tooltips " href="#">';
		  $html .='<span class="'.$position.' tooltip-'.$style.'">'.$title.$info.'<b></b></span>';
		  $html .=do_shortcode($content);
		  $html .='</a>';
		 return $html;
	
}
add_shortcode('furnicom_tooltip', 'furnicom_tooltip');


/*
 * Modal
 * @since v1.0
 *
 */
 
function furnicom_modal($attr, $content = null) {
            ob_start();
			$tag_id = 'myModal_'.rand().time();
			?>
			<a href="#<?php echo esc_attr( $tag_id ); ?>" role="button" class="btn btn-default" data-toggle="modal"><?php echo trim($attr['label']) ?></a>
 
			<!-- Modal -->
			<div id="<?php echo esc_attr( $tag_id ); ?>" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
				<div class="modal-dialog">
					<div class="modal-content">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal" aria-hidden="true">x</button>
							<h3 id="myModalLabel"><?php echo esc_html( trim($attr['header']) ) ?></h3>
						</div>
						<div class="modal-body">
							<?php echo $content; ?>
						</div>
						<div class="modal-footer">
							<button class="btn btn-default" data-dismiss="modal" aria-hidden="true"><?php echo esc_html( trim($attr['close']) ) ?></button>
							<button class="btn btn-primary"><?php echo esc_html( trim($attr['save']) ) ?></button>
						</div>
					</div>
				</div>
			</div>
            
            <?php
            $output_string = ob_get_contents();
            ob_end_clean();
            return $output_string;
        }
add_shortcode('furnicom_modal', 'furnicom_modal');

/*
 * Videos shortcode
 *
 */
 
// register the shortcode to wrap html around the content
function videos($atts, $content=null) {
	extract(
		shortcode_atts(array(
			'site' => '',
			'id' => '',
			'w' => '',
			'h' => ''
		), $atts)
	);
	if ( $site == "youtube" ) { $src = 'http://www.youtube-nocookie.com/embed/'.esc_attr( $id ); }
	else if ( $site == "vimeo" ) { $src = 'http://player.vimeo.com/video/'.esc_attr( $id ); }
	else if ( $site == "dailymotion" ) { $src = 'http://www.dailymotion.com/embed/video/'.esc_attr( $id ); }
	else if ( $site == "yahoo" ) { $src = 'http://d.yimg.com/nl/vyc/site/player.html#vid='.esc_attr( $id ); }
	else if ( $site == "bliptv" ) { $src = 'http://a.blip.tv/scripts/shoggplayer.html#file=http://blip.tv/rss/flash/'.esc_attr( $id ); }
	else if ( $site == "veoh" ) { $src = 'http://www.veoh.com/static/swf/veoh/SPL.swf?videoAutoPlay=0&permalinkId='.esc_attr( $id ); }
	else if ( $site == "viddler" ) { $src = 'http://www.viddler.com/simple/'.esc_attr( $id )
	; }
	if ( $id != '' ) {
		return '<iframe width="'.esc_attr( $w ).'" height="'.esc_attr( $h ).'" src="'.esc_attr( $src ).'" class="vid iframe-'.esc_attr( $site ).'"></iframe>';
	}
}
/*
 * Audios shortcode
 *
 */
// register the shortcode to wrap html around the content
function furnicom_audio_shortcode( $atts ) {
    extract( shortcode_atts( array (
        'identifier' => ''
    ), $atts ) );
    return '<div class="yt-audio-container"><iframe width="100%" height="166" frameborder="no" scrolling="no" src="https://w.soundcloud.com/player/?url=' . esc_attr( $identifier ) . '"></iframe></div>';
}
add_shortcode ('soundcloud-audio', 'furnicom_audio_shortcode' );
/*
 * Post slide 
 *
 */
function furnicom_post_slide( $atts ) {
	extract( shortcode_atts( array( 'title'=>'','style_title'=>'title1','limit' => 6,'categories'=>'','length'=> 40,'type'=>'','interval'=>'5000','el_class'=>''), $atts ) );
    $list = get_posts( array('cat' =>$categories,'posts_per_page' =>  $limit) );
	$html = '<div id="yt_post_slide" class="carousel  yt_post_slide_'.esc_attr( $type ).' slide content '.esc_attr( $el_class ).'" data-ride="carousel" data-interval="'.esc_attr( $interval ).'">';
	if($title != ''){
	$html.='<div class="block-title '.esc_attr( $style_title ).'">';
if($style_title == 'title3'){
	$wordChunks = explode(" ", $title);
	$firstchunk = $wordChunks[0];
	$secondchunk = $wordChunks[1];
$html.='<h2> <span>'.$firstchunk.'</span> <span class="text-color"> '.esc_html( $secondchunk ).' </span></h2>';
}else{
$html.='<h2>
				<span>'.esc_html( $title ).'</span>
	</h2>' ;
}	
}
	$html.=	'<div class="customNavigation nav-left-product">
				<a title="Previous" class="btn-bs prev-bs fa fa-angle-left"  href=".yt_post_slide_'.esc_attr( $type ).'" role="button" data-slide="prev"></a>
				<a title="Next" class="btn-bs next-bs fa fa-angle-right" href=".yt_post_slide_'.esc_attr( $type ).'" role="button" data-slide="next"></a>
			</div>
		</div>';
    $html .= '<div class="carousel-inner">';
	foreach( $list as $i => $item ){
	  $html .= '<div class="item ';
				if($i == 0)
				{$html .='active ';} 
				$html .='">';
	  $html .='<a href="'.get_permalink($item->ID).'" title="'.esc_attr( $item->post_title ).'">'.get_the_post_thumbnail($item->ID).'</a>';
	  $html .='  <div class="carousel-caption-'.esc_attr( $type ).' carousel-caption">
      	         <div class="carousel-caption-inner">
				 <a href="'.get_permalink($item->ID).'">'.esc_html( $item->post_title ).'</a>';	
	  $html .='<div class="item-description">'.wp_trim_words($item->post_content,$length).'</div>';
	  $html .='</div></div></div>';  
	}
	  $html .='</div>';
	  $html .='<div class="carousel-cl-'.esc_attr( $type ).' carousel-cl" >';
	  $html .=	'<a class="left carousel-control" href=".yt_post_slide_'.esc_attr( $type ).'" role="button" data-slide="prev"></a>';
	  $html .='<a class="right carousel-control" href=".yt_post_slide_'.esc_attr( $type ).'" role="button" data-slide="next"></a>';
	  $html .='</div>';
	  $html .='</div>';
	return $html;
}
add_shortcode ('postslide', 'furnicom_post_slide' );
/*
 * Lightbox image
 *
 */
 function furnicom_lightbox_shortcode($atts){
	  extract( shortcode_atts( array (
        'id' => '',
		'style'=>'',
		'size'=>'thumbnail',
		'class'=>'',
		'title'=>''
    ), $atts ) );
	add_action('wp_footer', 'add_script_lightbox', 50);
	return '<div class="lightbox '.esc_attr( $class ).' lightbox-'.esc_attr( $style ).'" ><a id="single_image" href="' . wp_get_attachment_url($id) . '">'.wp_get_attachment_image($id,$size).'</a><div class="caption"><h4>'.$title.'</h4></div></div>';
 }
 add_shortcode ('lightbox', 'furnicom_lightbox_shortcode' );
 function add_script_lightbox(){
	$script = '';
	$script .= '<script type="text/javascript">
	 jQuery(document).ready(function($) {
		  "use strict";
		 $("a#single_image").fancybox();
		 });
	</script>';
	echo $script;
 }
 /*
 * Heading tag
 *
 */
 function furnicom_heading_shortcode($atts,$content = null){
	 extract( shortcode_atts( array (
        'heading' => '',
		'type'=>'',
		'color'=>'',
		'icon'=>'',
        'class'=>'', 		
		'bg'=>''
    ), $atts ) );
	if( $icon != ''||$color !=''||$bg !=''||$class !=''){
			return '<span class="'.$class.'" style="background:'.$bg.';color:'.$color.'"><i class="fa '.esc_attr( $icon ).'"></i>'.do_shortcode($content);
		}
	if($heading !=''){
	  return '<'.$heading.' style="font-weight:'.esc_attr( $type ).'">'.do_shortcode($content).'</'.$heading.'>';
	}
 }
 add_shortcode('headings','furnicom_heading_shortcode');

  /*
 * Divider
 *
 */
 function furnicom_divider_shortcode ($atts){
	 extract(shortcode_atts(array(
	 'position' =>'top',
	 'title'=>'',
	 'style'=>'',
	 'type'=>'',
	 'width' =>'auto',
	 'widthbd'=>'1px',
	 'color' =>'#d1d1d1'
	 ),$atts));
	 if($position !=''&&$type !='LR'){
		 return '<h4 style="text-align: center;">'.$title.'</h4><hr style ="border-'.$position.':'.$widthbd.' '.$style.' '.$color.';width:'.$width.';margin-top:10px">';
	 }
	 if($type == 'LR'){
		 return'<div class="rpl-title-wrapper"><h4>'.$title.'</h4></div><hr style ="border-'.$position.':'.$widthbd.' '.$style.' '.$color.';width:'.$width.';margin-top:-20px">';
	 }
	
 }
 add_shortcode('divider','furnicom_divider_shortcode');
 /*
 * Tables
 *
 */
 function furnicom_simple_table( $atts ) {
    extract( shortcode_atts( array(
        'cols' => 'none',
        'data' => 'none',
		'class'=>'',
		'style'=>''
    ), $atts ) );
    $cols = explode(',',$cols);
    $data = explode(',',$data);
    $total = count($cols);
    $output = '<table class="table-'.$style.' '.$class.'"><tr class="th">';
    foreach($cols as $col):
        $output .= '<td>'.$col.'</td>';
    endforeach;
    $output .= '</tr><tr>';
    $counter = 1;
    foreach($data as $datum):
        $output .= '<td>'.$datum.'</td>';
        if($counter%$total==0):
            $output .= '</tr>';
        endif;
        $counter++;
    endforeach;
        $output .= '</table>';
    return $output;
}
add_shortcode( 'tables', 'furnicom_simple_table' );
/*
 * Block quotes
 *
 */
 function furnicom_quote_shortcode( $atts,$content = null ) {
    extract( shortcode_atts( array(
		'style'=>''
    ), $atts ) );
	return '<div class="quote-'.$style.'">'.do_shortcode($content).'</div>';
 }
 add_shortcode ('quotes','furnicom_quote_shortcode');
 /*
 * Counter box
 *
 */
 function yt_counter_box($atts){
extract( shortcode_atts( array(
		'style'=>'',
		'icon'=>'',
	    'number'=>'',
		'type'=>''
      ), $atts ) );
	  add_action('wp_footer', 'add_script_counterbox', 50);
	  wp_enqueue_script('furnicom_waypoints_api', 'http://cdnjs.cloudflare.com/ajax/libs/waypoints/2.0.3/waypoints.min.js', array('jquery'), null, true);
	if($icon !=''){
		$icon= '<i class="'.$icon.'"></i>';
	}
	return'<div class="counter-'.$style.'"><ul><li class="counterbox-number">'.$icon.''.$number.'</li><li class="type">'.$type.'</li></ul></div>';
}
add_shortcode('counters','yt_counter_box');
 function add_script_counterbox(){
	$script = '';
	$script .='<script type="text/javascript">';
	$script .= 'jQuery(document).ready(function( $ ) {
        $(".counterbox-number").counterUp({
            delay: 10,
            time: 1000
        });
    });';
	$script .='</script>';
	echo $script;
 }
 /*
 * Social
 *
 */
 function furnicom_social_shortcode($atts){
	 extract(shortcode_atts(array(
	 'style'=>'',
	 'background'=>'',
	 'icon'=>'',
	 'link'=>'',
	 'title'=>''
	 ),$atts));
	 $bg='';
	 if($background !=''){
		 $bg = 'style="background:'.$background.'"';
	 }
	 return '<div id="socials" class="socials-'.$style.'" '.$bg.'><a href="'.esc_url( $link ).'" title="'.esc_attr( $title ).'"><i class="fa '.$icon.'"></i></a></div>';
 }
 add_shortcode('socials','furnicom_social_shortcode');
  /*
 * Related product
 *
 */
 function furnicom_nav_title_shortcode($atts){
	 extract(shortcode_atts(array(
	 'number' => 5,
	 'title'=>'Related Product',
	 'el_class'=>'',
	 'template'=>''
	 ),$atts));
	 global $product, $woocommerce_loop,$wp_query;
	$related = $product->get_related( $number );
	if ( sizeof( $related ) == 0 ) return;
	$args = apply_filters( 'woocommerce_related_products_args', array(
		'post_type'            => 'product',
		'ignore_sticky_posts'  => 1,
		'no_found_rows'        => 1,
		'posts_per_page'       => $number,
		'post__in'             => $related,
		'post__not_in'         => array( $product->id )
	) );
	$num_post  = count($related);
	$relate = new WP_Query( $args );
	
	if ($relate->have_posts()) :
	$i = 0;
	$j = 0;
	$k = 0;
	 $pf_id = 'bestsale-'.rand().time();
	if($template == 'indicators'){
		$output='<div id="'.$pf_id.'" class="carousel slide sw-related-product" data-ride="carousel">';
		$output.='<ul class="list-unstyled carousel-indicators">';
		 while( $relate->have_posts() ) : $relate->the_post(); 
				if( $j % 3 == 0 ){
					  $active = ( $j == 0 ) ? 'active' : '';	
		$output.='<li data-target="#'.$pf_id.'" data-slide-to="'.$k.'" class="'.$active.'"></li>';
				
			 $k++; } $j++;  endwhile; wp_reset_postdata(); 
		$output.='</ul>';
	}
	if($template == 'slide'){
		$output ='<div id="'.$pf_id.'" class="carousel slide sw-related-product '.$el_class.'" data-ride="carousel" data-interval="0">';
	$output.='<div class="block-title title1">
			<h2>
				<span>'.$title.'</span>
			</h2>
			<div class="customNavigation nav-left-product">
				<a title="Previous" class="btn-bs prev-bs fa fa-angle-left"  href="#'.$pf_id.'" role="button" data-slide="prev"></a>
				<a title="Next" class="btn-bs next-bs fa fa-angle-right" href="#'.$pf_id.'" role="button" data-slide="next"></a>
			</div>
		</div>';
	}
		$output.='<div class="carousel-inner">';
			while ($relate->have_posts()) : $relate->the_post();
			global $product, $post, $wpdb, $average;
			$count = $wpdb->get_var($wpdb->prepare("
				SELECT COUNT(meta_value) FROM $wpdb->commentmeta
				LEFT JOIN $wpdb->comments ON $wpdb->commentmeta.comment_id = $wpdb->comments.comment_ID
				WHERE meta_key = 'rating'
				AND comment_post_ID = %d
				AND comment_approved = '1'
				AND meta_value > 0
			",$post->ID));

			$rating = $wpdb->get_var($wpdb->prepare("
				SELECT SUM(meta_value) FROM $wpdb->commentmeta
				LEFT JOIN $wpdb->comments ON $wpdb->commentmeta.comment_id = $wpdb->comments.comment_ID
				WHERE meta_key = 'rating'
				AND comment_post_ID = %d
				AND comment_approved = '1'
			",$post->ID));
			if( $i % 4 == 0 ){
				$active = ( $i == 0 ) ? 'active' : '';		
				$output.='<div class="item '.$active.'" >';
				}
			$output.='<div class="bs-item cf">';
	        $output.='<div class="bs-item-inner">';
			$output.='<div class="item-img">';
	$output.='<a href="'.get_permalink($post->ID).'" title="'.esc_attr( $post->post_title ).'">';
					 if( has_post_thumbnail() ){  
	$output.= (get_the_post_thumbnail( $relate->post->ID, 'shop_thumbnail' )) ? get_the_post_thumbnail( $relate->post->ID, 'shop_thumbnail' ):'<img src="'.get_template_directory_uri().'/assets/img/placeholder/shop_thumbnail.png" alt="No thumb"/>' ;
					}else{ 
	$output.= '<img src="'.get_template_directory_uri().'/assets/img/placeholder/shop_thumbnail.png" alt="No thumb"/>' ;
					} 
	$output.='</a>';
	$output.='</div>';
	$output.='<div class="item-content">';
	if( $count > 0 ){
						$average = number_format($rating / $count, 1);
				
	$output.='<div class="star"><span style="width:'.($average*14).'px'.'"></span></div>';
					
			 } else { 
				
	$output.='<div class="star"></div>';
					
				}
	$output.='<h4><a href="'.get_permalink($post->ID).'" title="'.esc_attr( $post->post_title ).'">'.esc_html( $post->post_title ).'</a></h4>';
    $output.= '<p>'.$product->get_price_html().'</p>';
	$output.='</div></div></div>';
			 if( ( $i+1 )%4==0 || ( $i+1 ) == $num_post  ){ 
			 $output.='</div>';
			 } 
			 $i++; endwhile; 
		$output.='</div>
	</div>';
	endif;
	wp_reset_postdata();
	return $output;
	
 }
  add_shortcode('yt_related_product','yt_related_product_shortcode');
 /**  Nav Title Style **/
 function yt_nav_title_shortcode($atts,$content = null){
	 extract(shortcode_atts(array(
	 'style'=>'',
	 'color'=>'',
	 'tag'=>'h2',
	 'icon'=>'',
	 'font-color'=>''
	 ),$atts));
	if( $icon != '' ){
			$icon = '<i class="'.$icon.'"></i>';
		}
		return '<section class="block-title '.$style.'">
		<'.$tag.'><span>'.$icon.do_shortcode($content).'</span></'.$tag.'>
	</section>';
 }
 add_shortcode('Title','furnicom_nav_title_shortcode');
 /*
 * OUR BRAND
 *
 */
 function furnicom_our_brand_shortcode($atts){
	 extract( shortcode_atts( array(
	'title' => '',
	'description' => '',
	'type'=>'default',
	'style_title'=>'',
	'numberposts' => 5,
	'orderby'=>'',
	'order' => '',
	'post_status' => 'publish',
	'columns'=>'',
	'columns1'=>'',
	'columns2'=>'',
	'columns3'=>'',
	'columns4'=>'',
	'interval'=>'',
	'effect'=>'slide',
	'hover'=>'hover',
	'swipe'=>'yes',
	'el_class' => ''
), $atts ) );
$tag_id ='sw_partner_slider_'.rand().time();
		$default = array(
			'post_type' => 'partner',
			'orderby' => $orderby,
			'order' => $order,
			'post_status' => 'publish',
			'showposts' => $numberposts
		);
	$list = new WP_Query( $default );
if($type == 'default'){
$output='<div class="'.$el_class.' block-brand">';
if($title !=''){
$output.='<div class="block-title '.$style_title.'">';
if($style_title == 'title3'){
	$wordChunks = explode(" ", $title);
	$firstchunk = $wordChunks[0];
	$secondchunk = $wordChunks[1];
$output.='<h2> <span>'.$firstchunk.'</span> <span class="text-color"> '.$secondchunk.' </span></h2>';
}else {
	$output.='<h2>
				<span>'.$title.'</span>
			</h2>';
    }
}
$output.='</div>';
$output.='<div class="block-content">
				<div class="brand-wrapper">
					<ul>';
				while($list->have_posts()): $list->the_post();
						global  $post;
						$output.='<li><a href="'.get_permalink($post->ID).'" title="'.$post->post_title.'">'.get_the_post_thumbnail($post->ID).'</a></li>';
                     endwhile; wp_reset_postdata();
$output.='</ul>
				</div>
			</div>
		</div>';
		return $output;
}
if($type == 'slide'){
$output='<div id="'.$tag_id.'" class="sw-partner-container-slider flex-slider '.$el_class.'">';
$output.='<div class="page-button top">
				<ul class="control-button preload">
					<li class="preview"></li>
					<li class="next"></li>
				</ul>		
			</div>';
	$count_items = 0;
		if($numberposts >= $list->found_posts){$count_items = $list->found_posts; }else{$count_items = $numberposts;}
		//var_dump($list);
		if($columns > $count_items){
			$columns = $count_items;
		}
		
		if($columns1 > $count_items){
			$columns1 = $count_items;
		}
		
		if($columns2 > $count_items){
			$columns2 = $count_items;
		}
		
		if($columns3 > $count_items){
			$columns3 = $count_items;
		}
		
		if($columns4 > $count_items){
			$columns4 = $count_items;
		}
		
		$deviceclass_sfx = 'preset01-'.$columns.' '.'preset02-'.$columns1.' '.'preset03-'.$columns2.' '.'preset04-'.$columns3.' '.'preset05-'.$columns4;
$output.='<div class="slider not-js cols-6 '.$deviceclass_sfx.'" data-interval="'.$interval.'" data-effect="'.$effect.'" data-hover="'.$hover.'" data-swipe="'.$swipe.'">
			<div class="vpo-wrap">
				<div class="vp">
					<div class="vpi-wrap">';
						while($list->have_posts()): $list->the_post();
						global  $post;
						$link = get_post_meta( $post->ID, 'link', true );
						$target = get_post_meta( $post->ID, 'target', true );
						$description = get_post_meta( $post->ID, 'description', true );
$output.='<div class="item">
							<div class="item-wrap">';							
								if(has_post_thumbnail()){ 
								$output.='	<div class="item-img item-height">
										<div class="item-img-info">
											<a href="'.esc_url( $link ).'" title="'.esc_attr( $post->post_title ).'" target="'.$target.'">
												'.get_the_post_thumbnail($post->ID).'
											</a>
										</div>
									</div>';
								 }else{ 
$output.='      <div class="item-img item-height">
										<div class="item-img-info">
											<a href="'.esc_url( $link ).'" title="'.esc_attr( $post->post_title ).'" target="'.$target.'">
												<img src="'.get_template_directory_uri().'/assets/img/placeholder/thumbnail.png" alt="No thumb">;
											</a>
										</div>
									</div>';
								 }
								 if( $description != '' ){ 
							$output.='<div class="item-desc">';
								$output.= $description.'
									</div>';		
								 }
						$output.='	</div>
						</div>';
					 endwhile; wp_reset_postdata();
					$output.='</div>
				</div>
			</div>
		</div>
	</div>';
	return $output;
	}
}
add_shortcode('OurBrand','furnicom_our_brand_shortcode');
function furnicom_get_url_shortcode($atts) {
	 if(is_front_page()){
		 $frontpage_ID = get_option('page_on_front');
		 $link =  get_site_url().'/?page_id='.$frontpage_ID ;
		 return $link;
	 }
	 elseif(is_page()){
		$pageid = get_the_ID();
		 $link = get_site_url().'/?page_id='.$pageid ;
		 return $link;
	 }
	 else{
		 $link = $_SERVER['REQUEST_URI'];
		 return $link;
	 }
	 
	 
 }
 add_shortcode('get_url','furnicom_get_url_shortcode');
 /*
 * Vertical mega menu
 *
 */
 function yt_vertical_megamenu_shortcode($atts){
	 extract( shortcode_atts( array(
	'menu_locate' =>'',
	'title'  =>'',
	'style' =>'',
	'el_class' => ''
), $atts ) );
$output = '<div class="vc_wp_custommenu wpb_content_element ' . $el_class . ' '.$style.'">';
if($title != ''){
$output.='<div class="mega-left-title">
				<strong>'.$title.'</strong>
			</div>';
}
$output.='<div class="wrapper_vertical_menu vertical_megamenu">';
ob_start();
$output .= wp_nav_menu( array( 'menu' => $menu_locate, 'menu_class' => 'nav vertical-megamenu' ) );
$output .= ob_get_clean();
$output .= '</div></div>';
return $output;
 }
 add_shortcode('furnicom_mega_menu','yt_vertical_megamenu_shortcode');
/*
   * Shortcode popular product
   *
*/ 
  function Furnicom_Featured($atts){
	extract(shortcode_atts(array(
		'title' => '',
		'category' => '',
		'numberposts' => '',
		'orderby' => '',
		'order' => '',
		'post_status' => 'publish',
		'el_class' => ''
		), $atts));
	if($category != 0){
		$default = array(
			'post_type'				=> 'product',
			'post_status' 			=> 'publish',
			'tax_query'	=> array(
				array(
					'taxonomy'	=> 'product_cat',
					'field'		=> 'id',
					'terms'		=> $category)),
			'ignore_sticky_posts'	=> 1,
			'posts_per_page' 		=> $numberposts,
			'orderby' 				=> $orderby,
			'order' 				=> $order,
			'meta_query'			=> array(
				array(
					'key' 		=> '_featured',
					'value' 	=> 'yes'
				)
			)
		);
	}else{
		$default = array(
			'post_type'				=> 'product',
			'posts_per_page' 		=> $numberposts,
			'orderby' 				=> $orderby,
			'order' 				=> $order
		);
	}
	$default['meta_query'] = WC()->query->get_meta_query();
	$list = new WP_Query( $default );
	$tag_id = 'furnicom_featured_'.rand().time();
	$output = '';
	$output .='<div id='.$tag_id.' class="sw-featured-product featured-product">';
	if( $title != '' ){
		$titles = strpos($title, ' ');
	$output .='<div class="box-slider-title"><h2><span>' . substr( $title, 0, $titles ) . '</span> ' . substr( $title, $titles + 1 ) . '</h2></div>';
	}
	$output .='<div class="featured-content">';
		while($list->have_posts()): $list->the_post();
		global $product, $post, $wpdb, $average;
	$output .='<div class="item"><div class="item-detail">';
	$output .='<div class="item-thumb pull-left">';
	$output .='<a href="'.get_permalink($post->ID).'" title="'.esc_attr( $post->post_title ).'">';
			if( has_post_thumbnail() ){  
				$output .= get_the_post_thumbnail( $list->post->ID, 'furnicom_toprated') ? get_the_post_thumbnail( $list->post->ID, 'furnicom_toprated' ) : '<img src="'.get_template_directory_uri().'/assets/img/placeholder/shop_thumbnail.png" alt="No thumb"/>';
			}else{ 
				$output .= '<img src="'.get_template_directory_uri().'/assets/img/placeholder/shop_thumbnail.png" alt="No thumb"/>' ;
			} 
	$output .='</a></div>';
	
	$output .='<div class="item-content">';
	$output .='<h4><a href="'.get_permalink($post->ID).'" title="'.esc_attr( $post->post_title ).'">'. esc_html( $post->post_title ) .'</a></h4>';
			if ( $price_html = $product->get_price_html() ){								
					$output	.='<div class="item-price"><span>';
					$output .= $price_html;
					$output	.='	</span></div>';
				 }								
			$rating_count = $product->get_rating_count();
			$review_count = $product->get_review_count();
			$average      = $product->get_average_rating();
	$output.='<div class="reviews-content">';
	$average > 0;
	$output.='<div class="star"><span style="width:'.($average*15).'px'.'"></span></div>';
	$output .='<div class="item-number-rating">';
	$output .='</div>';
	$output .='</div>';	 
	$output .='</div>';
	$output .='</div></div>';
		endwhile; wp_reset_query();
	$output .='</div>';
	$output .='</div>';
	return $output;
  }
  add_shortcode('furnicom_featured','Furnicom_Featured');
/*
   * Shortcode change logo footer 
   *
*/
 	function furnicom_change_logo( $atts ){
		extract(shortcode_atts(array(
		'title' => '',
		'colorset' => '',
		'post_status' => 'publish',
		'el_class' => ''
		), $atts));
		$furnicom_colorset = furnicom_options()->getCpanelValue('scheme');
		$site_logo = furnicom_options()->getCpanelValue('sitelogo');
		//var_dump($name);
		$output   ='';
		$output  .='<div class="ya-logo">';
		$output	 .='<a  href='.esc_url( home_url( '/' ) ).'>';
					$logo = get_template_directory_uri().'/assets/img/logo-footer.png';
		$output  .='<img src="'.esc_attr( $logo ).'" alt="logo-footer" />';		
		$output	 .='</a>';
		$output  .='</div>';
		return $output; 
  	}
  	add_shortcode('logo_footer','furnicom_change_logo');
/**
 * Clean up gallery_shortcode()
 *
 * Re-create the [gallery] shortcode and use thumbnails styling from Bootstrap
 *
 * @link http://twitter.github.com/bootstrap/components.html#thumbnails
 */
function furnicom_gallery($attr) {
	$post = get_post();

	static $instance = 0;
	$instance++;

	if (!empty($attr['ids'])) {
		if (empty($attr['orderby'])) {
			$attr['orderby'] = 'post__in';
		}
		$attr['include'] = $attr['ids'];
	}

	$output = apply_filters('post_gallery', '', $attr);

	if ($output != '') {
		return $output;
	}

	if (isset($attr['orderby'])) {
		$attr['orderby'] = sanitize_sql_orderby($attr['orderby']);
		if (!$attr['orderby']) {
			unset($attr['orderby']);
		}
	}

	extract(shortcode_atts(array(
		'order'      => 'ASC',
		'orderby'    => 'menu_order ID',
		'id'         => $post->ID,
		'itemtag'    => '',
		'icontag'    => '',
		'captiontag' => '',
		'columns'    => 3,
		'size'       => 'thumbnail',
		'include'    => '',
		'exclude'    => ''
		), $attr)
	);

	$id = intval($id);

	if ($order === 'RAND') {
		$orderby = 'none';
	}

	if (!empty($include)) {
		$_attachments = get_posts(array('include' => $include, 'post_status' => 'inherit', 'post_type' => 'attachment', 'post_mime_type' => 'image', 'order' => $order, 'orderby' => $orderby));

		$attachments = array();
		foreach ($_attachments as $key => $val) {
			$attachments[$val->ID] = $_attachments[$key];
		}
	} elseif (!empty($exclude)) {
		$attachments = get_children(array('post_parent' => $id, 'exclude' => $exclude, 'post_status' => 'inherit', 'post_type' => 'attachment', 'post_mime_type' => 'image', 'order' => $order, 'orderby' => $orderby));
	} else {
		$attachments = get_children(array('post_parent' => $id, 'post_status' => 'inherit', 'post_type' => 'attachment', 'post_mime_type' => 'image', 'order' => $order, 'orderby' => $orderby));
	}

	if (empty($attachments)) {
		return '';
	}

	if (is_feed()) {
		$output = "\n";
		foreach ($attachments as $att_id => $attachment) {
			$output .= wp_get_attachment_link($att_id, $size, true) . "\n";
		}
		return $output;
	}
	
	if (!wp_style_is('furnicom_photobox_css')){
		wp_enqueue_style('furnicom_photobox_css');
	}
	
	if (!wp_enqueue_script('photobox_js')){
		wp_enqueue_script('photobox_js');
	}
	
	$output = '<ul id="photobox-gallery-' . esc_attr( $instance ). '" class="thumbnails photobox-gallery gallery gallery-columns-'.esc_attr( $columns ).'">';

	$i = 0;
	$width = 100/$columns - 1;
	foreach ($attachments as $id => $attachment) {
		//$link = isset($attr['link']) && 'file' == $attr['link'] ? wp_get_attachment_link($id, $size, false, false) : wp_get_attachment_link($id, $size, true, false);
		$link = '<a class="thumbnail" href="' .esc_url( wp_get_attachment_url($id) ) . '">';
		$link .= wp_get_attachment_image($id);
		$link .= '</a>';
		
		$output .= '<li style="width: '.esc_attr( $width ).'%;">' . $link;
		$output .= '</li>';
	}

	$output .= '</ul>';
	
	add_action('wp_footer', 'furnicom_add_script_gallery', 50);
	
	return $output;
}
add_action( 'after_setup_theme', 'furnicom_setup_gallery', 20 );
function furnicom_setup_gallery(){
	if ( current_theme_supports('bootstrap-gallery') ) {
		remove_shortcode('gallery');
		add_shortcode('gallery', 'furnicom_gallery');
	}
}

function furnicom_add_script_gallery() {
	$script = '';
	$script .= '<script type="text/javascript">
				jQuery(document).ready(function($) {
					try{
						// photobox
						$(".photobox-gallery").each(function(){
							$("#" + this.id).photobox("li a");
							// or with a fancier selector and some settings, and a callback:
							$("#" + this.id).photobox("li:first a", { thumbs:false, time:0 }, imageLoaded);
							function imageLoaded(){
								console.log("image has been loaded...");
							}
						})
					} catch(e){
						console.log( e );
					}
				});
			</script>';
	
	echo $script;
}