<?php get_header() ?>
<?php 
	$furnicom_p_imgintro = furnicom_options()->getCpanelValue( 'portfolio_imgintro' );
?>
<div class="container">
	<div class="portfolio-intro">
		
	<?php
	if( $furnicom_p_imgintro != '' ){
		echo '<img src="' . $furnicom_p_imgintro . '"/>';
	}
	echo '<h2 class="p-title">'. __( 'Portfolio', 'furnicom' ) .'</h2>';
	if ( function_exists( 'furnicom_breadcrumb' ) ){
		furnicom_breadcrumb( '<div class="breadcrumbs theme-clearfix">', '</div>' );
	} 

	?>
	</div>
</div>

	<div class="container">
		<?php			
			$portfolio 		= array();
			$attributes 	= '';
			$number 		= 8;
			$orderby 		= 'date'; 
			$order			= '';
			$portfolio_id 	= furnicom_options()->getCpanelValue( 'portfolio_id' );
			$style			= furnicom_options()->getCpanelValue( 'p_style' );
			$col1	 		= furnicom_options()->getCpanelValue( 'p_col_large' );
			$col2		 	= furnicom_options()->getCpanelValue( 'p_col_medium' );
			$col3			= furnicom_options()->getCpanelValue( 'p_col_sm' );
			$col4			= furnicom_options()->getCpanelValue( 'p_col_xs' );			
			$pf_id			= 'furnicom_portfolio';
			if( count( $portfolio_id  ) > 0 ){
				$portfolio = $portfolio_id;
			}else{
				$terms = get_terms( 'portfolio_cat' );
				foreach( $terms as $k => $term ){
					$portfolio[$k] = $term -> term_id;
				}
			}
			include( plugin_dir_path( __FILE__ ) . 'portfolio-item.php' );
		?>
	</div>
<?php get_footer() ?>